from distutils.core import setup
setup(name='BoxOffice', version='1.0', py_modules=['gui','getFromInternet','mysmtplib'])